/*	
Stewart Wehmeyer
7/7/2016
JavaScript
HOMM3 Project 3 submission
Use a slider to adjust VALUES!
Linked to Community.html and mysite.css
mysite.js
*/

	
//This "$(function"()) container keeps the jQuery from executing before all of the page is "ready"

$(function()	{
	$("#sliderVisual").slider({
		value: 0,
		min: 0,
		max: 1000,
		step: 10,
		
		
			slide: function( event, ui) {
				$( "#hours" ).val( ui.value + " hours" );
			}
	});
	
	$( "#hours" ).val("Please move the slider");
	
});

$(function(){
	var currentIndex = 0,
	items = $('.container div'),
	itemAmt = items.length;
	
	function cycleItems() {
		var item = $('.container div').eq(currentIndex)
		items.hide();
		item.css('display','inline-block');
	}
	
	var autoSlide = setInterval(fuction() {
		currentIndex += 1;
		if (currentIndex > itemAmt - 1) {
			currentIndex = 0;
		}
		cycleItems();
	}, 3000);
	
	$('.next').click(function() {
		clearInterval(autoSlide);
		currentIndex +=1;
		if (currentIndex > itemAmt -1) {
			currentIndex = 0;
		}
		cycleItems();
	});
	
	$('.prev').click(function() {
		clearInterval(autoSlide);
		currentIndex -= 1;
		if (currentIndex < 0) {
			currentIndex = itemAmt - 1;
		}
		cycleItems();
	});
});